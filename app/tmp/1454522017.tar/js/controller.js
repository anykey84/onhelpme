'use strict';

var sitebackupApp = angular.module('sitebackupApp', []);

sitebackupApp.controller('indexController', function($scope, $http){

})